import GoogleMobileAds
import UIKit

@MainActor
final class AdMobManager: NSObject, FullScreenContentDelegate {
    static let shared = AdMobManager()

    private let testAdUnitID = "ca-app-pub-3940256099942544/4411468910"
    private var interstitial: InterstitialAd?
    private var isLoading = false
    private var isPresenting = false

    private var adUnitID: String {
        let configured = Bundle.main.object(forInfoDictionaryKey: "AdMobInterstitialAdUnitID") as? String
#if DEBUG
        return testAdUnitID
#else
        return configured?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false
            ? configured!
            : testAdUnitID
#endif
    }

    func start() {
        MobileAds.shared.start()
        loadInterstitial()
    }

    func showInterstitial(from viewController: UIViewController) {
        guard !isPresenting, let interstitial else {
            loadInterstitial()
            return
        }

        do {
            try interstitial.canPresent(from: viewController)
        } catch {
            self.interstitial = nil
            loadInterstitial()
            return
        }

        isPresenting = true
        self.interstitial = nil
        interstitial.fullScreenContentDelegate = self
        interstitial.present(from: viewController)
    }

    private func loadInterstitial() {
        guard !isLoading, interstitial == nil else { return }
        isLoading = true

        Task { @MainActor [weak self] in
            guard let self else { return }
            defer { isLoading = false }

            do {
                let ad = try await InterstitialAd.load(with: adUnitID, request: Request())
                ad.fullScreenContentDelegate = self
                interstitial = ad
            } catch {
                interstitial = nil
                print("[AdMob] Failed to load interstitial: \(error.localizedDescription)")
            }
        }
    }

    func ad(
        _ ad: FullScreenPresentingAd,
        didFailToPresentFullScreenContentWithError error: Error
    ) {
        isPresenting = false
        print("[AdMob] Failed to present interstitial: \(error.localizedDescription)")
        loadInterstitial()
    }

    func adDidDismissFullScreenContent(_ ad: FullScreenPresentingAd) {
        isPresenting = false
        loadInterstitial()
    }
}
