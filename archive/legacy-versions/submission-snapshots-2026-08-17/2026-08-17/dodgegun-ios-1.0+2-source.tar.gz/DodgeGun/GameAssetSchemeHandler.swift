import Foundation
import UniformTypeIdentifiers
import WebKit

final class GameAssetSchemeHandler: NSObject, WKURLSchemeHandler {
    static let scheme = "dodgegun"

    private let root: URL
    private var stopped = Set<ObjectIdentifier>()

    init(root: URL) {
        self.root = root.standardizedFileURL
    }

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        let token = ObjectIdentifier(urlSchemeTask)
        guard let requestURL = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }

        let relative = normalizedPath(from: requestURL)
        let fileURL = root.appendingPathComponent(relative).standardizedFileURL
        guard fileURL.path.hasPrefix(root.path) else {
            fail(urlSchemeTask, token: token, status: 403)
            return
        }
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            fail(urlSchemeTask, token: token, status: 404)
            return
        }

        do {
            let data = try Data(contentsOf: fileURL)
            let mime = mimeType(for: fileURL)
            let range = byteRange(from: urlSchemeTask.request, total: data.count)
            let body: Data
            let status: Int
            var headers: [String: String] = [
                "Content-Type": mime,
                "Access-Control-Allow-Origin": "*",
                "Accept-Ranges": "bytes",
                "Cache-Control": "public, max-age=0",
            ]

            if let range {
                body = data.subdata(in: range.lowerBound..<range.upperBound)
                status = 206
                headers["Content-Range"] = "bytes \(range.lowerBound)-\(range.upperBound - 1)/\(data.count)"
                headers["Content-Length"] = String(body.count)
            } else {
                body = data
                status = 200
                headers["Content-Length"] = String(body.count)
            }

            guard let response = HTTPURLResponse(url: requestURL, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers) else {
                urlSchemeTask.didFailWithError(URLError(.cannotParseResponse))
                return
            }
            guard !stopped.contains(token) else { return }
            urlSchemeTask.didReceive(response)
            if urlSchemeTask.request.httpMethod != "HEAD" {
                urlSchemeTask.didReceive(body)
            }
            urlSchemeTask.didFinish()
        } catch {
            guard !stopped.contains(token) else { return }
            urlSchemeTask.didFailWithError(error)
        }
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        stopped.insert(ObjectIdentifier(urlSchemeTask))
    }

    private func normalizedPath(from url: URL) -> String {
        var path = url.path
        if path.hasPrefix("/") {
            path.removeFirst()
        }
        if path.isEmpty || path.hasSuffix("/") {
            path += "index.html"
        }
        return path.removingPercentEncoding ?? path
    }

    private func mimeType(for fileURL: URL) -> String {
        if let type = UTType(filenameExtension: fileURL.pathExtension), let mime = type.preferredMIMEType {
            return mime
        }
        switch fileURL.pathExtension.lowercased() {
        case "html": return "text/html"
        case "js": return "text/javascript"
        case "css": return "text/css"
        case "png": return "image/png"
        case "svg": return "image/svg+xml"
        case "mp3": return "audio/mpeg"
        case "ttf": return "font/ttf"
        default: return "application/octet-stream"
        }
    }

    private func byteRange(from request: URLRequest, total: Int) -> Range<Int>? {
        guard let header = request.value(forHTTPHeaderField: "Range"), header.hasPrefix("bytes=") else { return nil }
        let spec = header.dropFirst("bytes=".count)
        let parts = spec.split(separator: "-", maxSplits: 1, omittingEmptySubsequences: false)
        guard parts.count == 2 else { return nil }
        let start = Int(parts[0]) ?? 0
        let end = parts[1].isEmpty ? total - 1 : (Int(parts[1]) ?? (total - 1))
        guard start >= 0, start < total, end >= start, end < total else { return nil }
        return start..<(end + 1)
    }

    private func fail(_ task: WKURLSchemeTask, token: ObjectIdentifier, status: Int) {
        guard !stopped.contains(token), let url = task.request.url else { return }
        let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: [
            "Content-Type": "text/plain",
            "Content-Length": "0",
        ])
        if let response {
            task.didReceive(response)
            task.didFinish()
        } else {
            task.didFailWithError(URLError(.resourceUnavailable))
        }
    }
}
