#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")/../web"
npm install
npm run build
