import Link from "next/link";

export default function Home() {
  return (
    <main className="page-shell home-page">
      <div className="eyebrow">STUDIO ZZG / DODGEGUN</div>
      <h1>도지건<br /><span>안내 센터</span></h1>
      <p className="lead">
        한 발의 타이밍으로 승부하는 1대1 슈팅 게임, 도지건의 개인정보 처리방침과
        이용 지원 정보를 확인하세요.
      </p>
      <div className="card-grid">
        <Link className="info-card" href="/privacy">
          <span className="card-index">01</span>
          <strong>개인정보 처리방침</strong>
          <span>앱에서 처리하는 정보와 이용 목적을 확인합니다.</span>
        </Link>
        <Link className="info-card" href="/support">
          <span className="card-index">02</span>
          <strong>지원</strong>
          <span>실행, 조작, 빠른 대전 관련 도움을 받습니다.</span>
        </Link>
      </div>
      <footer className="site-footer">
        <span>© 2026 Studio ZZG</span>
        <a href="mailto:diploin1026@gmail.com">diploin1026@gmail.com</a>
      </footer>
    </main>
  );
}
