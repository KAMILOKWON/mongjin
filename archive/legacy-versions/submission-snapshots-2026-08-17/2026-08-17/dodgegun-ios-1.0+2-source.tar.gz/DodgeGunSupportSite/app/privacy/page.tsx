import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "개인정보 처리방침",
  description: "도지건 개인정보 처리방침",
};

export default function PrivacyPage() {
  return (
    <main className="page-shell doc-page">
      <nav className="doc-nav" aria-label="페이지 탐색">
        <Link className="brand" href="/">STUDIO ZZG / DODGEGUN</Link>
        <Link className="back-link" href="/">안내 센터로 돌아가기</Link>
      </nav>
      <header className="doc-header">
        <div className="eyebrow">PRIVACY / 2026. 08. 17.</div>
        <h1>개인정보 처리방침</h1>
        <p>Studio ZZG는 도지건 앱 사용자의 개인정보를 필요한 범위에서만 처리합니다.</p>
      </header>
      <article className="doc-content">
        <section><h2>1. 적용 범위</h2><p>이 방침은 iPhone용 게임 “도지건”(이하 “앱”)에 적용됩니다. Studio ZZG(이하 “운영자”)는 사용자의 개인정보를 보호하고 관련 문의에 답변하기 위해 이 방침을 제공합니다.</p></section>
        <section><h2>2. 처리하는 정보</h2><ul><li><strong>닉네임:</strong> 사용자가 앱 설정에서 입력하는 표시 이름입니다. 빠른 대전에서 상대에게 표시되고 매칭 요청에 사용될 수 있습니다.</li><li><strong>임시 사용자 ID:</strong> 앱이 기기에서 무작위로 생성하는 식별자입니다. 계정, 이름, 이메일 또는 광고 식별자와 연결되지 않습니다.</li><li><strong>빠른 대전 데이터:</strong> 빠른 대전을 이용할 때 매칭과 게임 진행을 위해 이동·조준·발사·장전 등 게임 입력과 현재 경기 상태가 설정된 게임 서버로 전송됩니다.</li><li><strong>기기 내 전적 및 설정:</strong> 닉네임, 사운드·햅틱 설정, 튜토리얼 완료 여부와 경기 전적은 기본적으로 기기 안에 저장됩니다.</li></ul><p>앱은 회원가입, 결제, 광고, 분석 SDK, 연락처·사진·카메라·마이크·위치 권한을 요구하지 않습니다.</p></section>
        <section><h2>3. 이용 목적</h2><p>운영자는 위 정보를 게임 실행, 사용자 설정 저장, 빠른 대전 매칭과 경기 진행, 오류 대응 및 서비스 보안에 사용합니다. 운영자는 개인정보를 광고 또는 맞춤형 마케팅 목적으로 사용하지 않습니다.</p></section>
        <section><h2>4. 보관 및 삭제</h2><p>기기에 저장된 정보는 앱을 삭제하거나 앱의 저장 데이터를 초기화하면 삭제됩니다. 빠른 대전 데이터는 실시간 게임 서비스를 제공하는 데 필요한 동안 처리되며, 게임 서버의 운영·보안 로그는 서버 운영 정책에 따라 제한된 기간 동안 보관될 수 있습니다.</p></section>
        <section><h2>5. 제3자 서비스</h2><p>빠른 대전은 사용자가 설정한 게임 서버와 실시간 통신할 수 있습니다. 사용자가 외부 서버 주소를 직접 설정한 경우, 해당 서버 운영자의 개인정보 처리방침과 보관 정책이 함께 적용될 수 있습니다.</p></section>
        <section><h2>6. 이용자의 문의</h2><p>개인정보 처리에 관한 문의, 열람 또는 삭제 요청은 아래 이메일로 보내 주세요. 요청을 확인한 뒤 합리적인 기간 안에 답변하겠습니다.</p><div className="contact-box"><a href="mailto:diploin1026@gmail.com">diploin1026@gmail.com</a></div></section>
        <section><h2>7. 방침 변경</h2><p>서비스 기능이나 관련 법령의 변경에 따라 이 방침을 수정할 수 있습니다. 변경된 방침은 이 페이지에 게시한 날부터 적용됩니다.</p></section>
      </article>
    </main>
  );
}
