import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "지원",
  description: "도지건 게임 지원 및 문의",
};

export default function SupportPage() {
  return (
    <main className="page-shell doc-page">
      <nav className="doc-nav" aria-label="페이지 탐색">
        <Link className="brand" href="/">STUDIO ZZG / DODGEGUN</Link>
        <Link className="back-link" href="/">안내 센터로 돌아가기</Link>
      </nav>
      <header className="doc-header">
        <div className="eyebrow">SUPPORT / DODGEGUN</div>
        <h1>도지건 지원</h1>
        <p>가로 화면 전용 1대1 슈팅 게임 도지건을 이용하면서 문제가 생겼나요?</p>
      </header>
      <article className="doc-content">
        <div className="support-grid">
          <section className="support-item"><h2>게임 시작</h2><p>첫 실행 후 튜토리얼을 완료하면 홈 화면에서 연습 대전을 시작할 수 있습니다. 연습 대전은 로그인 없이 AI와 플레이합니다.</p></section>
          <section className="support-item"><h2>조작 방법</h2><p>왼쪽 스틱으로 이동하고 오른쪽 스틱을 당겨 조준한 뒤 놓아서 발사합니다. 장전은 화면 안내에 따라 홀드하여 진행합니다.</p></section>
          <section className="support-item"><h2>빠른 대전</h2><p>빠른 대전은 설정된 게임 서버에 연결합니다. 서버에 연결할 수 없으면 AI 폴백으로 동작할 수 있습니다. 네트워크가 불안정하면 Wi‑Fi 또는 안정적인 모바일 네트워크에서 다시 시도해 주세요.</p></section>
          <section className="support-item"><h2>문의하기</h2><p>문제 상황, 사용 중인 iPhone 모델, iOS 버전, 재현 방법을 함께 보내 주시면 확인에 도움이 됩니다.</p><div className="contact-box"><a href="mailto:diploin1026@gmail.com">diploin1026@gmail.com</a></div></section>
        </div>
      </article>
    </main>
  );
}
