# 도지건 iOS

앱인토스 `도지건-앱인토스` 게임을 그대로 담은 가로 전용 iOS 앱입니다.

시뮬·전투·AI·렌더·조작·BGM·탄약 HUD는 원본과 같고, 토스 미니앱 SDK만 로컬 저장소와 iOS 햅틱으로 바꿨습니다.

## 실행

Xcode에서 `DodgeGun.xcodeproj`를 열고 시뮬레이터 또는 기기에 Run 합니다.

- 최소 iOS 16
- 가로 전용
- 번들 ID: `com.studiozzg.dodgegun`

실기기에 넣을 때는 Signing & Capabilities에서 Team을 선택하세요.

## 플레이

- 첫 실행: 스튜디오 스플래시 후 튜토리얼
- 연습하기: AI와 Bo3 (40초 라운드, 2선승)
- 빠른 대전: 설정한 Colyseus 서버에 붙고, 없으면 AI 폴백
- 랭킹: 이 기기 기록
- 왼 스틱 이동 / 오른 스틱 당겨서 조준·놓아서 발사 / 장전 홀드

웹 미리보기:

```bash
cd web
npm install
npm run dev
```

## 웹 번들 다시 만들기

게임 JS/CSS/에셋을 고친 뒤:

```bash
./scripts/build-web.sh
```

산출물은 `DodgeGun/Web/`에 들어가고 Xcode 리소스로 같이 빌드됩니다.

## 빠른 대전 서버

원본과 같은 Colyseus 서버입니다. `도지건-앱인토스`에서:

```bash
npm run server
```

앱 설정 → 대전 서버에 `ws://<맥 IP>:2567`을 넣으면 됩니다. 서버가 없으면 빠른 대전은 AI와 바로 붙습니다.
