import { defineConfig } from 'vite';

export default defineConfig({
  base: '/',
  server: {
    host: true,
    port: 5173,
  },
  preview: {
    host: true,
    port: 4173,
  },
  build: {
    outDir: '../DodgeGun/Web',
    emptyOutDir: true,
    target: 'es2020',
    assetsInlineLimit: 4096,
  },
});
