const s={registerApp(p){}};export{s as AppsInToss};
